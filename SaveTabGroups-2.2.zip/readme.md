# Save Tab Groups

Chrome Extension to save currently opened tab groups to be reloaded later.

Developed by Jon Fleming
[GitHub](https://github.com/jonfleming/SaveTabGroups)
