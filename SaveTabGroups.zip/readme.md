# Save Tab Groups

Simple Chrome Extension to save currently opened tab groups to be reloaded later