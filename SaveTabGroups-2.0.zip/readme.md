# Save Tab Groups

Chrome Extension to save currently opened tab groups to be reloaded later.

Developed by Jon Fleming
https://github.com/jonfleming/SaveTabGroups
